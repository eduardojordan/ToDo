package io.keepcoding.todo.data.repository

interface TaskRepository {
}